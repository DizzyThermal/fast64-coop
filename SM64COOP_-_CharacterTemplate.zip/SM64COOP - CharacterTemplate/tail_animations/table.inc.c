const struct Animation *const anims[] = {
	&mario_anim_72,
	&mario_anim_4D,
	&mario_anim_C3,
	&mario_anim_C4,
	&mario_anim_C5,
	&mario_anim_50,
	&mario_anim_4C,
	&mario_anim_56,
	&mario_anim_57,
	NULL,
};
